<?php
header('Content-Type: application/json'); // Response will be in JSON format
header('Access-Control-Allow-Origin: *'); // Allow all origins to access the resource
header('Cache-Control: no-cache, no-store, must-revalidate'); // Do not cache the response
