<?php
error_reporting(0);
ini_set('display_errors', 0);
?>

<?php
/** Database connection credentials for localhost **/
define("host", "localhost");
define("user", "root");
define("password", "");
define("database", "app_data");




?>



